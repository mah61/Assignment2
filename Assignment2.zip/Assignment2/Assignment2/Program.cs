﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Frequency of each element in an array
namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myArr = {12,3,5,12,7,12,3};

            // creating an object of the Frequency class in order to call its method
            Frequency calculFrequency = new Frequency();
            calculFrequency.GetUniqueElement(myArr);


        }

    }

}


