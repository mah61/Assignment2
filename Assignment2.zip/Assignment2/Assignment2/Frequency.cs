﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Frequency
    {
        public void GetUniqueElement(int[] myArr)
        {

            int i, j;
            int[] countArr = new int[myArr.Length]; //defining a new array to store the count of each element
            int count = 0;

            //giving the value of -1 for the elements of countArr
            for (i = 0; i < myArr.Length; i++)
            {
                countArr[i] = -1;
            }

            for (i = 0; i < myArr.Length; i++)
            {
                count = 1;
                for (j = i + 1; j < myArr.Length; j++)
                {

                    if (myArr[i] == myArr[j])

                    {
                        count++;
                        countArr[j] = 0; //in order to reconize the repeated elements in the array  
                    }
                }

                if (countArr[i] != 0) //in order to keep 0 count for repeated elements  
                {
                    countArr[i] = count;
                }

            }

            // print the frequency of each element in the array

            for (i = 0; i < countArr.Length; i++)

            {

                if (countArr[i] != 0) //in order to ignore printing the count of repeated elements
                {

                    Console.WriteLine("The frequency of element {0} is {1} ", myArr[i], countArr[i]);
                }

            }

        }

    }
}

